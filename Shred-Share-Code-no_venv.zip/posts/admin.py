from django.contrib import admin
from .models import Post, Mountain, Comment

admin.site.register(Post)
admin.site.register(Mountain)
admin.site.register(Comment)
